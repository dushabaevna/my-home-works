import DellItem from "./components/DellItem";
function App() {
  return (
    <DellItem/>
  )
}
export default App;