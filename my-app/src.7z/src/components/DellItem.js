import './scr/components/DellItem.css'

function DellItem () {
    return (
        <div className='.expense-item__price'>
        <h1>Peaksoft</h1>
        <h2 className='expense-item__description'>School</h2>
        <h3 className='expense-item'>Java Script</h3>
      </div>
    )
}

export default DellItem