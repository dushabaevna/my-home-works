import ExpenseItem from './components/ExpenseItem';
import Expenses from './components/Expenses'

function App() {
  const expenses = [
    {
      id: 'e1',
      title: 'dell',
      amount: 235,
      date: new Date(2019, 3, 4),
    },
    {
      id: 'e2',
      title: 'New TV',
      amount: 799.49,
      date: new Date(2020, 1, 28)
    },
    {
      id: 'e3',
      title: 'Car Insurance',
      amount: 294.67,
      date: new Date(2018, 9,9),
    },
    {
      id: 'e4',
      title: 'New Desk (Wooden)',
      amount: 450,
      date: new Date(2021, 12, 1),
    },
  ];

  return (
    <Expenses>
      <div>
          {
            expenses.map((element, index) => {
              return (
                <ExpenseItem 
                title={element.title}
                date={element.date}
                amount={element.amount}
                />
              )
            })
}
      </div>
    </Expenses>
  );
}

export default App;