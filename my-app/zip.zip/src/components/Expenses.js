import './Expense.css'

function Expenses(props){
    return(
        <div className='Expense'>
            {props.children}
        </div>
    )
}

export default Expenses;